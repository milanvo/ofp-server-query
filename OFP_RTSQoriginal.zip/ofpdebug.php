<?php
$title="[WKK] Operation Flashpoint Serverquery debugger V 2.5";
echo "
<title>
".$title." 
</title>
<html>
<body>
";

//
// Define you system here. Which system are you running PHP @
// 0 = Linux / Unix;
// 1 = Windows / Other
//
// The reason why this is important, is that PHP under Windows, does NOT currently support socket_timeout.
//
// Default = 0 (Linux).
//
$system=0;


//
// Definition of known values in OFPinfo query.
//
$knownvalues = array(
	"Servertype" => array(
		"Start" => "16",
		"End" => "16",
		"Value" => "0",
		"Remarks" => "#=1 if NO password, #=129 if password",
		),

	"Maxplayers" => array(
		"Start" => "20",
		"End" => "20",
		"Value" => "0",
		"Remarks" => "#=0 if unlimited, # minus 2=max players",
		),

	"# of players" => array(
		"Start" => "24",
		"End" => "24",
		"Value" => "0",
		"Remarks" => "# minus 2=players",
		),

	"Server version" => array(
		"Start" => "92",
		"End" => "92",
		"Value" => "0",
		"Remarks" => "#=version",
		),

	"Required version" => array(
		"Start" => "96",
		"End" => "96",
		"Value" => "0",
		"Remarks" => "#=required version",
		),

	"Game status" => array(
		"Start" => "100",
		"End" => "100",
		"Value" => "0",
		"Remarks" => "#=0 if no mission loaded, #<>0 if mission loaded, ALSO first char in Mission name",
		),

	"Mission name" => array(
		"Start" => "100",
		"End" => "139",
		"Value" => "0",
		"Remarks" => "#=Game status <> 0, string=Mission name",
		),

	"Servername" => array(
		"Start" => "144",
		"End" => "Until end of query",
		"Value" => "0",
		"Remarks" => "string=rest of query is servername. Filter all 0's out",
		),
	);

function timenow() {
	return doubleval(ereg_replace('^0\.([0-9]*) ([0-9]*)$','\\2.\\1',microtime()));
}	
	
//
// Read raw data from server
//

function getServerData($command,$serveraddress,$portnumber,$waittime) {
	global $query,$system;
	$serverdata="";
	$serverdatalen=0;
	
	if ($waittime< 500) $waittime= 500;
	if ($waittime>2000) $waittime=2000;
	$waittime=doubleval($waittime/1000.0);

	if (!$ofpsocket=fsockopen("udp://".$serveraddress,$portnumber,$errnr)) {
		echo "No connection";
		return false;
	}
	socket_set_blocking($ofpsocket,true);
	if ($system==0) socket_set_timeout($ofpsocket,0,500000);
	fwrite($ofpsocket,$command,strlen($command));	
	$starttime=timenow();

	if ($query=="ofpinfo") {
		do {
			$serverdata.=fgetc($ofpsocket);
			$serverdatalen++;
			$socketstatus=socket_get_status($ofpsocket);
			if (timenow()>($starttime+$waittime)) {
				echo "Connection timed out";
				fclose($ofpsocket);
				return false;
			}
		} while ($socketstatus["unread_bytes"]);
	} else {
		do {
			$serverdata.=fgetc($ofpsocket);
			$serverdatalen++;
			$socketstatus=socket_get_status($ofpsocket);
			if (timenow()>($starttime+$waittime)) {
				echo "Connection timed out";
				fclose($ofpsocket);
				return false;
			}
		} while (substr($serverdata,strlen($serverdata)-7)!="\\final\\");
		if ((substr($serverdata,strlen($serverdata)-7)!="\\final\\") || (substr($serverdata,1,8)!="gamename")) {
			echo "Data incomplete";
			return false;
		}
	}
	fclose($ofpsocket);
	return $serverdata;		
}	

function debugoutput ($serverdata) {
	global $perrow, $query, $knownvalues;
	echo "<table>";
	for ($counter=0; $counter<=(strlen ($serverdata)-1); $counter) {
		echo "<tr>";
		echo "<td align=\"right\">".$counter."</td><td align=\"right\">-</td><td align=\"right\">".($counter+($perrow-1))."</td>";
		echo "<td></td>";
		echo "<td></td>";
		echo "<td></td>";
		for ($count=1; $count<=$perrow; $count++) {
			if (substr($serverdata,$counter,1)) {
				echo "<td><b>".(bin2hex(substr($serverdata,$counter,1)))."</b></td>";
			} elseif (substr($serverdata,$counter,1) || ord(substr($serverdata,$counter,1))==48) {
				echo "<td><b>00</b></td>";
			} elseif (!substr($serverdata,$counter,1)) {
				echo "<td><b></b></td>";
			}
			$counter++;
		}
		echo "<td></td><td></td><td></td>";
		$counter2=$counter-$perrow;
		for ($count2=1; $count2<=$perrow; $count2++) {
			if (!ord(substr($serverdata,$counter2,1))==0) {
				echo "<td>".substr($serverdata,$counter2,1)."</td>";
			} elseif (substr($serverdata,$counter2,1)) {
				echo "<td>..</td>";
			}
			$counter2++;
		}
		echo "</tr>";
	}
	echo "</table>";
	if ($serverdata && $query=="ofpinfo") {
		echo "<br><br>";
		echo "<table border=1>";

		$servertype=ord(substr($serverdata,16,1));
		$maxplayers=(ord(substr($serverdata,20,1))-2);
		if ($maxplayers<0) $maxplayers=0;
		$players=(ord(substr($serverdata,24,1))-2);
		if ($players<0) $players=0;
		$ver=ord(substr($serverdata,92,1));
		$reqver=ord(substr($serverdata,96,1));
		$gamestatus=ord(substr($serverdata,100,1));
		if ($gamestatus <> 0) {
			$level=str_replace(chr(0),"",substr($serverdata,100,40));
		}
		$servername=str_replace(chr(0),"",substr($serverdata,144,strlen($serverdata)));
		$knownvalues["Servertype"]["Value"]=$servertype;
		$knownvalues["Maxplayers"]["Value"]=$maxplayers;
		$knownvalues["# of players"]["Value"]=$players;
		$knownvalues["Server version"]["Value"]=$ver;
		$knownvalues["Required version"]["Value"]=$reqver;
		$knownvalues["Game status"]["Value"]=$gamestatus;
		$knownvalues["Mission name"]["Value"]=$level;
		$knownvalues["Servername"]["Value"]=$servername;
		echo "<tr><td><b>Keyname:</b></td><td><b>Startpos:</b></td><td><b>Endpos:</b></td><td><b>Value:</b></td><td><b>Remark:</b></td></tr>";
		while (list($key, $subarray) = each($knownvalues)) {
			echo "<tr>";
			echo "<td>$key</td>";
			while (list($key, $val) = each($subarray) ) {
				echo "<td>$val</td>";
			}
			echo "</tr>";
		}
		echo "</table>";

	} elseif ($serverdata && $query=="gsinfo") {
		echo "<br><br>";
		// Remove \\final\\ text at end of data
		$serverdata=substr($serverdata,1,strlen($serverdata)-7);

		// Split data and fill into array
		$name_tok = strtok ($serverdata,"\\");
		$val_tok  = strtok ("\\");
		while (strlen($name_tok)) {
			if ($name_tok!="final") {
				$vars[$name_tok]=$val_tok;
			}	
			$name_tok = strtok ("\\");
			$val_tok  = strtok ("\\");
		}
		echo "<table border=1>";
		echo "<tr><td><b>Keyname:</b></td><td><b>Value:</b></td></tr>";
		for ($counter=0; $counter<count($vars); $counter++) {
			while (list($key, $val) = each($vars) ) {
				echo "<tr><td>$key</td><td>$val</td></tr>";
			}
		}
		echo "</table>";
	}
}


$timeout=2000;

if (!isset($perrow)) {
	$perrow=6;
}

if ($query=="ofpinfo") {
	//
	// The MAGIC query against MS DirectPlay - Gets native-info from native-OFP
	//
	$cmd=
	"\x00\x02\x12\x00".
	"\x01\x60\x98\x24".
	"\xF7\xBE\xD0\xD2".
	"\x11\x95\xEA\x00".
	"\xA0\xC9\xA5\x7F\x0B";
} elseif ($query=="gsinfo") {
	//
	// The Query against OFP / Gamespy - Gets info from OFP / Gamespy
	//
	$cmd="\\status\\";
	if (isset($gsport) && $gsport<>0) {
		$port=$gsport;
	} else {
		$port=$port+1;
	}
} else {
	if ($system==0) {
		$systemtype="Linux/Unix";
	} elseif ($system==1) {
		$systemtype="Windows";		
	} else {
		$systemtype="Unknown";
	}
	echo "
	<b><a href=\"http://www.wkk.dk\">$title</a></b> - 	Running at <b>".$systemtype."</b>
	<br>
	<br>
	<b>Please specify (in FORM below):</b>
	<br>
	Server-address/IP,
	<br>
	Port-number,
	<br>
	Query-type
	<br>
	# of databytes diplayed per row <i><b>(optional)</b></i>.
	<br>
	<br>
	<form method=POST action=$PHP_SELF?doquery=yes>
	<table>
		<tr>
			<td>Server-address/IP:</td>
			<td><input type=text name=server></td>
		</tr>
		<tr>
			<td>Port-number:</td>
			<td><input type=text name=port size=5 value=2234></td>
		</tr>
		<tr>
			<td>Query-type:</td>
			<td>
				<select size=2 name=query>
					<option selected value=gsinfo>Gamespy info</option>
					<option value=ofpinfo>Native OFP info</option>
				</select>
			</td>
		</tr>
		<tr>
			<td>Alternate port-number to do Gamespy query,<br>if running more than 1 server on same server-address/IP:</b></i></td>
			<td><input type=text name=gsport size=6></td>
		</tr>
		<tr>
			<td># of databytes diplayed per row <i><b>(optional)</b></i>.</td>
			<td><input type=text name=perrow size=3 value=6></td>
		</tr>
	</table>
	<input type=submit value=\"Query Server\" name=submit> <input type=reset value=Clear name=reset>
	</form>
	";
}

if (isset($doquery) && $query) {
	debugoutput ($serverdata=getServerData($cmd,$server,$port,$timeout));
}

?>
</body>
</html>