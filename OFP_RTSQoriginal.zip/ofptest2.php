<?php
require("ofp.php");

if (isset($launchgame)) {
	$arguments=explode(":",$launchgame);
	$serveradr=$arguments[0];
	$serverport=$arguments[1];
	$ip=gethostbyname($serveradr);
	header("Content-type: application/x-game-launch",false);
	header("Content-Disposition: attachment; filename=launchgame.eye",false);
	header("Content-Disposition: filename=launchgame.eye",false);
	echo "open OFP://$ip:$serverport";
	exit;
}
?>
<HTML>
<BODY>

<?php
$serveradr="xxxIP";
$serverport=xxxport;
$serverport2=$serverport;
$ofp=new Ofp;

if ($status=$ofp->getServerinfo($serveradr,$serverport,$serverport2,2000,"scores")) {

	echo "Launch Game @: <a href=\"$PHP_SELF?launchgame=$serveradr:$serverport\">$serveradr:$serverport</a>\n<br><br>\n";
	echo "<b>Basic server info</b>\n<br>\n";
	echo "<table border=1>";
	echo "<tr><td>Querytype</td><td>".$status."</td></tr>\n";
	echo "<tr><td>Hostname</td><td>".$ofp->m_servervars["hostname"]."</td></tr>\n";
	echo "<tr><td>Servertype</td><td>".$ofp->m_servervars["servertype"]."</td></tr>\n";
	echo "<tr><td>Serverver</td><td>".$ofp->m_servervars["gamever"]."</td></tr>\n";
	echo "<tr><td>Reqver</td><td>".$ofp->m_servervars["reqver"]."</td></tr>\n";
	echo "<tr><td>Missiontatus</td><td>".$ofp->m_servervars["gamestatus"]."</td></tr>\n";
	echo "<tr><td>Mission</td><td>".$ofp->m_servervars["gametype"]."</td></tr>\n";
	echo "<tr><td># players</td><td>".$ofp->m_servervars["numplayers"]."</td></tr>\n";
	echo "<tr><td>Max-players</td><td>".$ofp->m_servervars["maxplayers"]."</td></tr>\n";
	echo "</table>";

	if ($status=="extended" && $ofp->m_servervars["numplayers"]<>0) {
		echo "<br><br><b>Extended server info</b>\n<br>\n";
		echo "<table border=1>\n";

		if ($ofp->m_servervars["gamestatus"]=="Mission loaded") {
			echo "<table border=1>\n";
			echo "<tr><td>World</td><td>".$ofp->m_servervars["mapname"]."</td></tr>\n";
			echo "<tr><td>Gamelength (minutes)</td><td>".($ofp->m_servervars["param1"])."</td></tr>\n";
			echo "<tr><td>Frags / Captures to win</td><td>".$ofp->m_servervars["param2"]."</td></tr\n>";
			echo "</table>\n";

			if (is_array($ofp->m_playerinfo)) {
				echo "<br><br><b>Player table</b><br>\n";
				echo "<table border=1>\n";
				echo "<tr><td>Name:</td><td>Squad:</td><td>Score:</td><td>Deaths:</td></tr>\n";
				while (list(,$player) = each ($ofp->m_playerinfo)) {
					echo "<tr>\n";
			    echo "<td>".htmlspecialchars($player["name"])."</td>\n";
					echo "<td>".$player["team"]."</td>\n";
					echo "<td>".$player["score"]."</td>\n";
					echo "<td>".$player["deaths"]."</td>\n";
					echo "</tr>\n";
				}
				echo "</table>\n";
			}
		}
		echo "</table>\n";
	}
} else { 
	echo "Unable to contact server, probably down"."<br>\n";
}
?>
</BODY>
</HTML>