23/10-2001 Version 1.0
------------------------------------------------------------------------------------------------------
[WKK] Who Killed Kenny, does it again :-)
2001 Made by LordNam (lordnam@wkk.dk).
http://www.wkk.dk

Thanx to Henrik Schack Jensen, for code from the UT library - available @ 

http://www.gameserver.dk
AND
http://phpclasses.upperdesign.com/browse.html/package/187

- for doing all the SOCKET functions, versus UT game-servers.

I felt free to re-use the code, where possible, but done:
ALL the reverse-engineering on OFP queries
AND supplemental code (which is quite some lines now) myself.
------------------------------------------------------------------------------------------------------

Finally I got done, this is the source for querying OFP servers from PHP.

An example-file or 2, and a debugger for future purpose is conatained this archive as well.

Requirements: A server running PHP version 4.x is required, Linux OR Windows.

******************************************************************************************************
Remember to search for the $system VARIABLE in top of the file "ofp.php"
AND "ofpdebug.php", and set it for whatever system you run.

$system=0; // for Linux (default)
$system=1; // for Windows

This is important, cause Windows does NOT support timeout functions on sockets in PHP
This means, if an illegal address is entered, when running @ windows - Apache crashes.
So ONLY do queries, against servers you KNOW is up, when running @ windows.

If running @ Linux - this problem is NOT present.

Thats just the way PHP 4.x is ported to windows - sorry folks.
******************************************************************************************************

The source consists of the following files:
------------------------------------------------------------------------------------------------------

"ofp.php" (class/library for querying OFP servers)
"ofptest.php" (example-file showing how to query, display results on a webpage).
"ofptest2.php" (VERY SIMPLE, example-file2).
"ofpdebug.php"(debugger to show all values of query, done against servers).
"pixel1.gif" (1 pixel gif - black, for FANCY serverload graphics).
"pixel2.gif" (1 pixel gif - transparent, for FANCY serverload graphics).

All examples also shows how to launch the game directly from the webpage,
(this requires All Seeing Eye installed).

Thats it, happy coding.

I have tested the scripts on BOTH windows AND linux - and they work for me (running 4.0.6 of PHP)
