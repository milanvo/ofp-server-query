<?php
require("ofp.php");

$server="xxxip:xxxport";

/*
if (isset($launchgame)) {
	$arguments=explode(":",$launchgame);
	$serveradr=$arguments[0];
	$serverport=$arguments[1];
	$ip=gethostbyname($serveradr);
	header("Content-type: application/x-game-launch",false);
	header("Content-Disposition: attachment; filename=launchgame.eye",false);
	header("Content-Disposition: filename=launchgame.eye",false);
	echo "open OFP://$ip:$serverport";
	exit;
}
?>
<HTML>
<BODY>
<?php
/*
if (!isset($server) && !isset($doquery)) {
	echo"
	<form method=POST action=$PHP_SELF?doquery=yes>
	<table>
		<tr>
			<td>SERVER:PORT</td>
			<td><input type=text name=server></td>
		</tr>
		<tr>
			<td>Alternate port-number to do Gamespy query,<br>if running more than 1 server on same server-address/IP:</b></i></td>
			<td><input type=text name=gsport size=6></td>
		</tr>
	</table>
	<input type=submit value=\"Query Server\" name=submit> <input type=reset value=Clear name=reset>
	</form>
	";
	exit;
} else {
*/
	$arguments=explode(":",$server);
	$serveradr=$arguments[0];
	$serverport=$arguments[1];
	if (!isset($serverport2) && $gsport=="") {
		$serverport2=$serverport;
	} else {
		$serverport2=$gsport;		
	}
//}



$ofp=new Ofp;
// *************************************************************************************************
// * Syntax:                                                                                       *
// * getServerinfo($serveradr,$serverport,$serverport2,2000,"scores"), where:                      *
// *                                                                                               *
// * $serveradr=IP or FQDN (Fully qualified domain-name of server,                                 *
// * $serverport=portnumber, where game is hosted (default 2234), has to be set - even if default, *
// * $serverport2=portnumber to do extended GSA query on, default ($serverport+1=2235)             *
// *                                                                                               *
// * WARNING WARNING WARNING:                                                                      *
// * ------------------------                                                                      *
// * -- IF RUNNING MULTIPLE SERVERS ON SAME IP, BE SURE TO LEAVE 1 PORT FOR EXTENDED QUERY BETWEEN *
// * -- THE SERVERS HOSTED. E.G. NEVER HOST 1 GAME ON 2234 AND ANOTHER ON 2235, THEN THE FOLLOWING *
// * -- WILL HAPPEN: EXTENDED QUERY FOR GAME ON 2234,WILL BE ON 2236 AND EXTENDED FOR GAME ON 2235 *
// * -- WILL BE ON 2237                                                                            *
// * -- THIS IS MESSY, AND DONE BY MANY GAME HOSTERS                                               *
// *                                                                                               *
// * -- IF BEHIND A FIREWALL, BE SURE TO OPEN THE PORT FOR EXTENDED QUERIES AS WELL, OTHERWISE     *
// * -- NO PLAYERINFO, WORLDINFO, GAMELENGTH AND CAPS/FRAGS TO WIN, WILL BE QUERIED                *
// *                                                                                               *
// * 2000=timeout, leave this @ 2000 if querying, against servers with large ping.                 *
// * "scores"=sortby scores, other values to sort by: "names", "teams", "deaths"                   *
// *************************************************************************************************

// *************************************************************************************************
// * If $status gets defined, Success querying server, otherwise failure                           *
// *************************************************************************************************
if ($status=$ofp->getServerinfo($serveradr,$serverport,$serverport2,2000,"scores")) {


	// **********************************************************************************
	// * Print out server-values, e.g. $ofp->m_servervars["hostname"], for servername   *
	// **********************************************************************************
	echo "Launch Game @: <a href=\"$PHP_SELF?launchgame=$serveradr:$serverport\">$serveradr:$serverport</a>\n<br>\n";
	echo "For lauching PUBLIC games, ALL Seeing Eye HAS to be installed - Not running<br>\n";
	echo "For lauching PRIVATE games, ALL Seeing Eye HAS to be installed AND RUNNING (e.g. minimized)<br><br>\n";
	echo "<b>Basic server info</b>\n<br>\n";
	echo "<table border=1>";
	echo "<tr><td>Querytype</td><td>".$status."</td></tr>\n";
	echo "<tr><td>Hostname</td><td>".$ofp->m_servervars["hostname"]."</td></tr>\n";
	echo "<tr><td>Servertype</td><td>".$ofp->m_servervars["servertype"]."</td></tr>\n";
	echo "<tr><td>Serverver</td><td>".$ofp->m_servervars["gamever"]."</td></tr>\n";
	echo "<tr><td>Reqver</td><td>".$ofp->m_servervars["reqver"]."</td></tr>\n";
	echo "<tr><td>Missiontatus</td><td>".$ofp->m_servervars["gamestatus"]."</td></tr>\n";
	echo "<tr><td>Mission</td><td>".$ofp->m_servervars["gametype"]."</td></tr>\n";
	echo "<tr><td># players</td><td>".$ofp->m_servervars["numplayers"]."</td></tr>\n";
	echo "<tr><td>Max-players</td><td>".$ofp->m_servervars["maxplayers"]."</td></tr>\n";
	if ($ofp->m_servervars["numplayers"]==0) {
		$message="People come join";
	} elseif ($ofp->m_servervars["numplayers"]==1) {
		$message="People has started to join";
	} elseif ($ofp->m_servervars["numplayers"]>1 && $ofp->m_servervars["numplayers"]<=4) {
		$message="Join the fight";
	} elseif ($ofp->m_servervars["numplayers"]>5 && $ofp->m_servervars["numplayers"]<=6) {
		$message="War is on";
	} elseif ($ofp->m_servervars["numplayers"]>6 && $ofp->m_servervars["numplayers"]<=8) {
		$message="Hell is loose";
	} elseif ($ofp->m_servervars["numplayers"]>8) {
		$message="Apocalypse";
	}
	echo "<tr><td>Attention</td><td>".$message."</td></tr>\n";	
	if ($ofp->m_servervars["maxplayers"]=="Not set") {
		$serverload="Not set";
	} else {
		$serverload=$ofp->m_servervars["numplayers"]/$ofp->m_servervars["maxplayers"]*100;		
	}
	if ($serverload<>"Not set") {
		echo "<tr><td>Serverload</td><td>0%|<img src=\"pixel.gif\" height=8 width=$serverload border=0><img src=\"pixel2.gif\" height=8 width=".(100-$serverload)." border=0>|100% ($serverload%)</td></tr>\n";
	} 
	echo "</table>";
	// **********************************************************************************
	// * End of Basic info table                                                        *
	// **********************************************************************************


	// **********************************************************************************
	// * If $status == "extended" AND players>0, print out extended info of server      *
	// **********************************************************************************
	if ($status=="extended" && $ofp->m_servervars["numplayers"]<>0) {
		echo "<br><br><b>Extended server info</b>\n<br>\n";
		echo "<table border=1>\n";
		// **********************************************************************************
		// * If Mission is loaded, show Extended info, otherwise nobody is @ the server     *
		// **********************************************************************************
		if ($ofp->m_servervars["gamestatus"]=="Mission loaded") {
			echo "<table border=1>\n";
			echo "<tr><td>World</td><td>".$ofp->m_servervars["mapname"]."</td></tr>\n";
			echo "<tr><td>Gamelength (minutes)</td><td>".($ofp->m_servervars["param1"])."</td></tr>\n";
			echo "<tr><td>Frags / Captures to win</td><td>".$ofp->m_servervars["param2"]."</td></tr\n>";
			echo "</table>\n";
			// **********************************************************************************
			// * End of general Extended info table                                             *
			// **********************************************************************************

			// **********************************************************************************
			// * Print out player-info for ALL players on server | Only if Extended query       *
			// **********************************************************************************
			if (is_array($ofp->m_playerinfo)) {
				echo "<br><br><b>Player table</b><br>\n";
				echo "<table border=1>\n";
				echo "<tr><td>Name:</td><td>Squad:</td><td>Score:</td><td>Deaths:</td></tr>\n";
				while (list(,$player) = each ($ofp->m_playerinfo)) {
					echo "<tr>\n";
			    echo "<td>".htmlspecialchars($player["name"])."</td>\n";
					echo "<td>".$player["team"]."</td>\n";
					echo "<td>".$player["score"]."</td>\n";
					echo "<td>".$player["deaths"]."</td>\n";
					echo "</tr>\n";
				}
				echo "</table>\n";
				// **********************************************************************************
				// * End of player-info table                                                       *
				// **********************************************************************************
			}
		}
		echo "</table>\n";
		// **********************************************************************************
		// * End of Extended info table                                                     *
		// **********************************************************************************
	}
} else { 
	echo "Unable to contact server, probably down"."<br>\n";
}
?>
</BODY>
</HTML>